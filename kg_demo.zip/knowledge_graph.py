import networkx as nx

def build_patient_kg():
    """
    Builds a Knowledge Graph for a CP patient (Aarav)
    containing relationships, routines, vocabulary, and clinical profile.
    """
    G = nx.DiGraph()

     # ── PATIENT NODE ──────────────────────────────────────────────
    G.add_node("Aarav", type="Patient", age=8, cp_subtype="spastic_diplegia",
               linguistic_age=6.2, mcds_baseline=0.58, aac_device="Tobii Dynavox I-13")
    # ── PEOPLE NODES ──────────────────────────────────────────────
    G.add_node("Priya",     type="Person", role="mother",          nickname="mama",
               contact_frequency="daily",     communication_style="simple_sentences")
    G.add_node("Vijay",     type="Person", role="father",          nickname="papa",
               contact_frequency="daily",     communication_style="simple_sentences")
    G.add_node("Rohan",     type="Person", role="classmate",       nickname="Rohan",
               contact_frequency="weekdays",  shared_interests="dinosaurs,football")
    G.add_node("Dr. Meera", type="Person", role="speech_therapist",nickname="Dr. Meera",
               contact_frequency="weekly",    communication_style="structured")
    G.add_node("Dr. Sharma",type="Person", role="physiotherapist", nickname="Dr. Sharma",
               contact_frequency="twice_weekly", communication_style="clinical")
    
    # ── PATIENT → PEOPLE EDGES ────────────────────────────────────
    G.add_edge("Aarav", "Priya",      relation="calls",             label="mama")
    G.add_edge("Aarav", "Vijay",      relation="calls",             label="papa")
    G.add_edge("Aarav", "Rohan",      relation="plays_with",        label="classmate")
    G.add_edge("Aarav", "Dr. Meera",  relation="sees_for_therapy",  label="SLP")
    G.add_edge("Aarav", "Dr. Sharma", relation="trusts_for_medical",label="physio")

    # ── ROUTINE NODES ─────────────────────────────────────────────
    G.add_node("Morning Routine", type="Routine", time="07:30-09:00",
               location="home",
               activities="wake_up,breakfast,physiotherapy,school_bus",
               people_present="Priya,Vijay",
               common_utterances="I am ready,more juice,my leg hurts")
    G.add_node("School Time",     type="Routine", time="09:00-14:00",
               location="St. Mary's Special School",
               activities="class,lunch,therapy,play",
               people_present="Rohan,teachers",
               common_utterances="I want to play,help me,I am tired")
    G.add_node("Evening Routine", type="Routine", time="16:00-20:00",
               location="home",
               activities="homework,play,dinner,bedtime",
               people_present="Priya,Vijay",
               common_utterances="I am hungry,I want to watch TV,good night mama")
    
    # ── PATIENT → ROUTINE EDGES ───────────────────────────────────
    G.add_edge("Aarav", "Morning Routine", relation="has_routine")
    G.add_edge("Aarav", "School Time",     relation="has_routine")
    G.add_edge("Aarav", "Evening Routine", relation="has_routine")

    # ── VOCABULARY NODES ──────────────────────────────────────────
    vocab = [
        ("hungry",    "hungry",        ["want food", "tummy hurts"],       4.5,  "high",   "meal_time,discomfort"),
        ("juice",     "juice",         ["drink", "orange juice"],           3.0,  "high",   "meal_time,morning"),
        ("tired",     "sleepy",        ["tired", "need rest"],              4.0,  "medium", "evening,school"),
        ("pain",      "my leg hurts",  ["hurts", "pain"],                   5.0,  "medium", "physio,morning"),
        ("play",      "I want to play",["play time", "let us play"],        3.5,  "high",   "school,evening"),
        ("ready",     "I am ready",    ["all done", "finished"],            4.0,  "high",   "morning,transition"),
        ("help",      "help me",       ["I need help", "please help"],      3.8,  "medium", "school,therapy"),
        ("happy",     "I am happy",    ["feeling good", "yay"],             4.2,  "low",    "general"),
        ("television","I want TV",     ["show", "cartoon"],                 5.5,  "medium", "evening"),
        ("night",     "good night",    ["bye", "sleep time"],               3.5,  "medium", "bedtime"),
    ]

    for word, preferred, alternatives, acq_age, freq, tags in vocab:
        node_id = f"vocab:{word}"
        G.add_node(node_id, type="Vocabulary", word=word,
                   preferred_form=preferred, alternatives=str(alternatives),
                   acquisition_age=acq_age, frequency=freq, context_tags=tags)
        G.add_edge("Aarav", node_id, relation="prefers_vocab")

    # ── EPISODE NODES (past interactions) ─────────────────────────
    episodes = [
        ("ep_001", "2026-05-28", "morning",  "Priya",     "more juice please,I am ready mama",              0.61, True),
        ("ep_002", "2026-05-27", "therapy",  "Dr. Meera", "I want to play,help me,I am tired",              0.59, True),
        ("ep_003", "2026-05-26", "school",   "Rohan",     "let us play dinosaurs,I am happy",               0.63, True),
        ("ep_004", "2026-05-25", "physio",   "Dr. Sharma","my leg hurts,I am tired",                        0.55, False),
        ("ep_005", "2026-05-24", "evening",  "Vijay",     "I am hungry,I want TV,good night papa",          0.60, True),
    ]

    for ep_id, date, context, partner, utterances, mcds, success in episodes:
        G.add_node(ep_id, type="Episode", date=date, context=context,
                   partner=partner, utterances=utterances,
                   mcds_score=mcds, successful=success)
        G.add_edge("Aarav", ep_id, relation="had_episode")

    print(f"[KG] Built graph: {G.number_of_nodes()} nodes, {G.number_of_edges()} edges")
    return G

def query_kg_for_context(G: nx.DiGraph, current_context: str, conversation_partner: str) -> dict:
    """
    Queries the KG and returns a structured context dictionary
    that will be injected into the LLM prompt.
    """
    patient_data    = G.nodes["Aarav"]
    context_payload = {"patient": patient_data}

    # ── 1. Routine match ──────────────────────────────────────────
    routine_map = {
        "morning":  "Morning Routine",
        "school":   "School Time",
        "evening":  "Evening Routine",
        "therapy":  "School Time",
        "physio":   "Morning Routine",
    }
    matched_routine = routine_map.get(current_context.lower())
    if matched_routine and G.has_node(matched_routine):
        context_payload["routine"] = G.nodes[matched_routine]

    # ── 2. Conversation partner ───────────────────────────────────
    if G.has_node(conversation_partner):
        context_payload["partner"] = G.nodes[conversation_partner]
        if G.has_edge("Aarav", conversation_partner):
            context_payload["relationship"] = G.edges["Aarav", conversation_partner]

    # ── 3. Vocabulary for this context ───────────────────────────
    relevant_vocab = []
    for _, target, edge_data in G.out_edges("Aarav", data=True):
        if edge_data.get("relation") == "prefers_vocab":
            node = G.nodes[target]
            tags = node.get("context_tags", "")
            if current_context.lower() in tags or node.get("frequency") == "high":
                relevant_vocab.append({
                    "word":           node["word"],
                    "preferred_form": node["preferred_form"],
                    "frequency":      node["frequency"],
                })
    context_payload["vocabulary"] = relevant_vocab

    # ── 4. Past successful episodes in this context ───────────────
    past_episodes = []
    for _, target, edge_data in G.out_edges("Aarav", data=True):
        if edge_data.get("relation") == "had_episode":
            ep = G.nodes[target]
            if ep.get("context") == current_context.lower() and ep.get("successful"):
                past_episodes.append({
                    "utterances": ep["utterances"],
                    "mcds_score": ep["mcds_score"],
                    "partner":    ep["partner"],
                })
    context_payload["past_episodes"] = past_episodes

    return context_payload

def format_context_for_prompt(context: dict) -> str:
    """
    Serialises the KG context dict into a clean string
    that is injected as the system prompt for the LLM.
    """
    patient  = context.get("patient",  {})
    routine  = context.get("routine",  {})
    partner  = context.get("partner",  {})
    rel      = context.get("relationship", {})
    vocab    = context.get("vocabulary",   [])
    episodes = context.get("past_episodes",[])

    lines = [
        "=== PATIENT KNOWLEDGE GRAPH CONTEXT ===",
        f"Patient name    : Aarav",
        f"Age             : {patient.get('age')} (chronological), "
        f"{patient.get('linguistic_age')} (linguistic)",
        f"CP subtype      : {patient.get('cp_subtype')}",
        f"MCDS baseline   : {patient.get('mcds_baseline')}",
        f"AAC device      : {patient.get('aac_device')}",
    ]

    if routine:
        lines += [
            "",
            f"Current routine : {routine.get('time', '')}",
            f"Location        : {routine.get('location', '')}",
            f"Activities      : {routine.get('activities', '')}",
            f"People present  : {routine.get('people_present', '')}",
            f"Common phrases  : {routine.get('common_utterances', '')}",
        ]

    if partner:
        lines += [
            "",
            f"Talking to      : {partner.get('role', '')} "
            f"(Aarav calls them '{rel.get('label', partner.get('nickname',''))}') ",
            f"Comm. style     : {partner.get('communication_style', '')}",
        ]

    if vocab:
        lines.append("")
        lines.append("Preferred vocabulary for this context:")
        for v in vocab[:8]:
            lines.append(f"  • '{v['word']}' → Aarav says: \"{v['preferred_form']}\"  [{v['frequency']} frequency]")

    if episodes:
        lines.append("")
        lines.append("Past successful utterances in similar contexts:")
        for ep in episodes[:3]:
            lines.append(f"  • \"{ep['utterances']}\"  (MCDS: {ep['mcds_score']})")

    lines.append("=========================================")
    return "\n".join(lines)