#!/usr/bin/env python
import torch
from transformers import AutoTokenizer, AutoModelForCausalLM

MODEL_ID = "microsoft/Phi-3-mini-4k-instruct"

print("[TEST] Starting model load...")
device = "cuda" if torch.cuda.is_available() else "cpu"
dtype = torch.float16 if device == "cuda" else torch.float32

print(f"[TEST] Device: {device}, Dtype: {dtype}")

print("[TEST] Loading tokenizer...")
tokenizer = AutoTokenizer.from_pretrained(MODEL_ID, trust_remote_code=True)
print("[TEST] Tokenizer loaded.")

print("[TEST] Loading model...")
model = AutoModelForCausalLM.from_pretrained(
    MODEL_ID,
    dtype=dtype,
    device_map="auto",
    trust_remote_code=True,
    attn_implementation="eager",
)
print("[TEST] Model loaded successfully!")
