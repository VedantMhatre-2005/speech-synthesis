"""
CP Speech Synthesis — Knowledge Graph + LLM Demo
Run in VS Code with a CUDA GPU.

Usage:
    python main.py

The script:
  1. Builds the patient Knowledge Graph
  2. Loads a small instruction-tuned LLM (Phi-3-mini) on GPU
  3. Enters a chat loop where every response is grounded in the KG
"""

import torch
import warnings
warnings.filterwarnings("ignore")

from transformers import AutoTokenizer, AutoModelForCausalLM
from knowledge_graph import build_patient_kg, query_kg_for_context, format_context_for_prompt

# ── CONFIG ────────────────────────────────────────────────────────────────────
MODEL_ID   = "microsoft/Phi-3-mini-4k-instruct"   # ~3.8B params, fits on most GPUs
MAX_TOKENS = 50  # reduced for faster inference
TEMPERATURE= 0.7

# ── DEMO SCENARIOS (pre-defined for the demonstration) ────────────────────────
SCENARIOS = {
    "1": {"context": "morning",  "partner": "Priya",     "intent": "Aarav wants more juice at breakfast."},
    "2": {"context": "therapy",  "partner": "Dr. Meera", "intent": "Aarav is tired and wants to take a break."},
    "3": {"context": "school",   "partner": "Rohan",     "intent": "Aarav wants to play dinosaurs with his friend."},
    "4": {"context": "evening",  "partner": "Vijay",     "intent": "Aarav is hungry and wants dinner."},
    "5": {"context": "physio",   "partner": "Dr. Sharma","intent": "Aarav's leg is hurting during physiotherapy."},
}


def load_model():
    print(f"\n[MODEL] Loading {MODEL_ID} ...")
    print(f"[MODEL] CUDA available : {torch.cuda.is_available()}")
    if torch.cuda.is_available():
        print(f"[MODEL] GPU           : {torch.cuda.get_device_name(0)}")
        print(f"[MODEL] VRAM          : {torch.cuda.get_device_properties(0).total_memory / 1e9:.1f} GB")

    device     = "cuda" if torch.cuda.is_available() else "cpu"
    dtype      = torch.float16 if device == "cuda" else torch.float32

    tokenizer = AutoTokenizer.from_pretrained(MODEL_ID, trust_remote_code=True)
    model     = AutoModelForCausalLM.from_pretrained(
        MODEL_ID,
        torch_dtype=dtype,
        trust_remote_code=True,
        attn_implementation="eager",  # avoid rope_scaling issues
    )
    
    # Move model to device manually instead of using device_map
    model = model.to(device)

    print("[MODEL] Ready.\n")
    return model, tokenizer


def build_prompt(kg_context_str: str, intent: str) -> list[dict]:
    """
    Builds the chat-style messages list for Phi-3.
    The KG context is injected as the system message.
    """
    system_message = (
        "You are an Augmentative and Alternative Communication (AAC) assistant "
        "helping a child named Aarav who has cerebral palsy and uses dysarthric speech. "
        "Your ONLY job is to generate short, natural phrases that Aarav would say — "
        "grounded strictly in the patient context provided below. "
        "Use only vocabulary and sentence complexity appropriate to Aarav's linguistic age. "
        "Never use complex words. Keep responses to 1–3 short phrases. "
        "Do NOT explain or add commentary — output only what Aarav would say.\n\n"
        + kg_context_str
    )

    return [
        {"role": "system",    "content": system_message},
        {"role": "user",      "content": f"Intent: {intent}\n\nWhat would Aarav say?"},
    ]


def build_word_completion_prompt(kg_context_str: str, word: str) -> list[dict]:
    """
    Builds a prompt specifically for word completion / prediction.
    Given a single word, expand it to a full natural sentence.
    """
    system_message = (
        "You are an Augmentative and Alternative Communication (AAC) assistant "
        "helping a child named Aarav who has cerebral palsy and uses dysarthric speech. "
        "Your ONLY job is to complete a single word into a natural full sentence that Aarav would say. "
        "The word Aarav typed is the starting point. Expand it into 1-3 short phrases that make sense in context. "
        "Use only vocabulary and sentence complexity appropriate to Aarav's linguistic age. "
        "Never use complex words. Do NOT explain or add commentary — output only what Aarav would say.\n\n"
        + kg_context_str
    )

    return [
        {"role": "system",    "content": system_message},
        {"role": "user",      "content": f"Aarav typed the word: '{word}'\n\nWhat full sentence would Aarav say? Start with this word and complete the thought."},
    ]


def run_demo(model, tokenizer, G):
    print("=" * 60)
    print("  CP Knowledge Graph + LLM — Context Engineering Demo")
    print("=" * 60)
    print("\nThis demo shows how the KG grounds every LLM response")
    print("in Aarav's persistent patient profile.\n")

    while True:
        print("\nSelect a scenario (or 'q' to quit):")
        for key, val in SCENARIOS.items():
            print(f"  [{key}] {val['context'].capitalize():10s} | "
                  f"Partner: {val['partner']:12s} | {val['intent']}")
        print("  [c]   Custom intent (manual input)")
        print("  [w]   Word completion (single word → full sentence)")
        print("  [g]   Show full Knowledge Graph summary")

        choice = input("\nYour choice: ").strip().lower()

        if choice == "q":
            print("\n[EXIT] Goodbye.")
            break

        elif choice == "g":
            print("\n── KNOWLEDGE GRAPH SUMMARY ──────────────────────────────")
            print(f"  Nodes : {G.number_of_nodes()}")
            print(f"  Edges : {G.number_of_edges()}")
            print("\n  Node types:")
            type_counts = {}
            for _, data in G.nodes(data=True):
                t = data.get("type", "Unknown")
                type_counts[t] = type_counts.get(t, 0) + 1
            for t, c in type_counts.items():
                print(f"    {t:20s}: {c}")
            print("\n  Sample edges (Aarav → *):")
            for i, (_, target, data) in enumerate(G.out_edges("Aarav", data=True)):
                if i >= 10:
                    print(f"    ... and {G.out_degree('Aarav') - 10} more")
                    break
                print(f"    Aarav ──[{data.get('relation','?')}]──→ {target}")

        elif choice == "c":
            context = input("  Context (morning/school/therapy/physio/evening): ").strip()
            partner = input("  Partner name (e.g. Priya, Dr. Meera, Rohan): ").strip()
            intent  = input("  Describe what Aarav wants to communicate: ").strip()

        elif choice == "w":
            # Word completion mode
            word = input("  Enter a single word (e.g., 'juice', 'play', 'ready'): ").strip()
            if not word:
                print("[!] Please enter a word.")
                continue
            
            # Use default morning context with mother
            context = "morning"
            partner = "Priya"
            intent  = f"Aarav wants to say '{word}'"

        elif choice in SCENARIOS:
            scenario = SCENARIOS[choice]
            context  = scenario["context"]
            partner  = scenario["partner"]
            intent   = scenario["intent"]

        else:
            print("[!] Invalid choice.")
            continue

        if choice in SCENARIOS or choice == "c" or choice == "w":
            # ── Query KG ──────────────────────────────────────────
            print(f"\n[KG] Querying graph for context='{context}', partner='{partner}' ...")
            kg_context    = query_kg_for_context(G, context, partner)
            kg_context_str= format_context_for_prompt(kg_context)

            print("\n── KG CONTEXT INJECTED INTO LLM ─────────────────────────")
            print(kg_context_str)

            # ── Build prompt and run LLM ───────────────────────────
            if choice == "w":
                # Word completion mode
                word = intent.replace("Aarav wants to say '", "").replace("'", "")
                messages = build_word_completion_prompt(kg_context_str, word)
            else:
                messages = build_prompt(kg_context_str, intent)

            print("\n[LLM] Generating response (GPU) ...")
            
            # Convert messages to text for tokenization
            system_msg = next(m["content"] for m in messages if m["role"] == "system")
            user_msg = next(m["content"] for m in messages if m["role"] == "user")
            full_prompt = f"<s>[INST] {system_msg}\n\n{user_msg} [/INST]"
            
            # Tokenize 
            inputs = tokenizer(full_prompt, return_tensors="pt")
            input_ids = inputs["input_ids"].to(model.device)
            attention_mask = inputs["attention_mask"].to(model.device)
            
            # Manual generation loop to avoid accelerate hooks
            with torch.no_grad():
                for _ in range(MAX_TOKENS):
                    outputs = model(input_ids, attention_mask=attention_mask, use_cache=False)
                    logits = outputs.logits[:, -1, :]
                    
                    # Greedy decoding (faster than sampling)
                    next_token_id = torch.argmax(logits, dim=-1, keepdim=True)
                    
                    # Stop if EOS token
                    if next_token_id.item() == tokenizer.eos_token_id:
                        break
                    
                    input_ids = torch.cat([input_ids, next_token_id], dim=-1)
                    attention_mask = torch.cat([attention_mask, torch.ones((1, 1), device=model.device)], dim=-1)
            
            response = tokenizer.decode(input_ids[0][inputs["input_ids"].shape[1]:], skip_special_tokens=True).strip()

            print("\n── LLM RESPONSE (KG-Grounded) ────────────────────────────")
            if choice == "w":
                word = intent.replace("Aarav wants to say '", "").replace("'", "")
                print(f"  Input word : '{word}'")
            else:
                print(f"  Intent : {intent}")
            print(f"  Output : \"{response}\"")
            print("──────────────────────────────────────────────────────────")


def main():
    # Build KG
    G = build_patient_kg()

    # Load LLM on GPU
    model, tokenizer = load_model()

    # Run interactive demo
    run_demo(model, tokenizer, G)


if __name__ == "__main__":
    main()